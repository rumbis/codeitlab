package com.swmansion.rnscreens.tabs.screen

import android.content.res.Configuration
import android.os.Parcelable
import android.util.SparseArray
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.facebook.react.uimanager.ThemedReactContext
import com.swmansion.rnscreens.common.FragmentProviding
import com.swmansion.rnscreens.common.container.Container
import com.swmansion.rnscreens.common.container.ContainerItem
import com.swmansion.rnscreens.common.container.ContainerItemSupport
import com.swmansion.rnscreens.scrollviewmarker.ScrollViewMarker
import com.swmansion.rnscreens.scrollviewmarker.ScrollViewSeeking
import com.swmansion.rnscreens.tabs.appearance.TabsAppearance
import com.swmansion.rnscreens.utils.RNSLog
import java.lang.ref.WeakReference
import kotlin.properties.Delegates

/**
 * React Component view.
 */
class TabsScreen(
    val reactContext: ThemedReactContext,
) : ViewGroup(reactContext),
    FragmentProviding,
    ScrollViewSeeking,
    ContainerItem {
    private var tabsScreenDelegate: WeakReference<TabsScreenDelegate> = WeakReference(null)
    private val containerItemSupport = ContainerItemSupport()

    internal lateinit var eventEmitter: TabsScreenEventEmitter

    var screenKey: String? = null
        set(value) {
            field =
                if (value?.isBlank() == true) {
                    null
                } else {
                    value
                }
        }

    internal val requireScreenKey: String
        get() = checkNotNull(screenKey) { "[RNScreens] screenKey MUST NOT be null" }

    var tabTitle: String? by Delegates.observable(null) { _, oldValue, newValue ->
        updateMenuItemAttributesIfNeeded(oldValue, newValue)
    }

    // region Appearance

    internal var appearance: TabsAppearance? by Delegates.observable(null) { _, oldValue, newValue ->
        if (oldValue != newValue) {
            if (invalidateMenuItemSizesIfNeeded(oldValue, newValue)) {
                tabsScreenDelegate.get()?.onItemSizeChange(this)
            } else {
                tabsScreenDelegate.get()?.onAppearanceChanged(this)
            }
        }
    }

    // endregion

    // region Badge

    var badgeValue: String? by Delegates.observable(null) { _, oldValue, newValue ->
        updateMenuItemAttributesIfNeeded(oldValue, newValue)
    }

    // endregion

    // region Accessibility
    var tabBarItemTestID: String? by Delegates.observable(null) { _, oldValue, newValue ->
        updateMenuItemAttributesIfNeeded(oldValue, newValue)
    }

    var tabBarItemAccessibilityLabel: String? by Delegates.observable(null) { _, oldValue, newValue ->
        updateMenuItemAttributesIfNeeded(oldValue, newValue)
    }

    // endregion

    // region Icon

    internal val icon = TabsScreenIcon(reactContext, ::onIconChange)
    internal val selectedIcon = TabsScreenIcon(reactContext, ::onIconChange)

    internal var isMenuItemIconInvalidated = true

    internal var isMenuItemActiveIndicatorInvalidated = true

    internal var appliedActiveIndicatorWidthPx: Int? = null

    internal var appliedActiveIndicatorHeightPx: Int? = null

    internal fun resolveIconsIfNeeded() {
        icon.resolveIfNeeded()
        selectedIcon.resolveIfNeeded()
    }

    private fun invalidateMenuItemSizesIfNeeded(
        oldValue: TabsAppearance?,
        newValue: TabsAppearance?,
    ): Boolean {
        val isIconSizeChanged = oldValue?.tabBarItemIconSize != newValue?.tabBarItemIconSize
        val isActiveIndicatorSizeChanged =
            oldValue?.tabBarItemActiveIndicatorWidth != newValue?.tabBarItemActiveIndicatorWidth ||
                oldValue?.tabBarItemActiveIndicatorHeight != newValue?.tabBarItemActiveIndicatorHeight
        if (isIconSizeChanged) {
            isMenuItemIconInvalidated = true
        }
        if (isIconSizeChanged || isActiveIndicatorSizeChanged) {
            isMenuItemActiveIndicatorInvalidated = true
            return true
        }
        return false
    }

    // endregion

    var shouldUseRepeatedTabSelectionScrollToTopSpecialEffect: Boolean = true
    var shouldUseRepeatedTabSelectionPopToRootSpecialEffect: Boolean = true

    var preventNativeSelection: Boolean = false

    private fun <T> updateMenuItemAttributesIfNeeded(
        oldValue: T,
        newValue: T,
    ) {
        if (newValue != oldValue) {
            onMenuItemAttributesChange()
        }
    }

    override fun onAttachedToWindow() {
        RNSLog.d(TAG, "TabsScreen [$id] attached to window")
        super.onAttachedToWindow()
    }

    override fun shouldDelayChildPressedState(): Boolean = false

    override fun onLayout(
        changed: Boolean,
        l: Int,
        t: Int,
        r: Int,
        b: Int,
    ) = Unit

    override fun dispatchSaveInstanceState(container: SparseArray<Parcelable>) {
        // Do nothing. React Native owns this view hierarchy and keeps it alive, so there is no
        // need to serialize/deserialize native view state. View ids in this subtree are react
        // tags, which are not stable identities - restoring state by id can apply state saved
        // by one view type to a different one, crashing e.g. in CompoundButton (see #4523).
    }

    override fun dispatchRestoreInstanceState(container: SparseArray<Parcelable>) {
        // Ignore restoring instance state too, as we are not saving anything anyways.
    }

    internal fun setTabsScreenDelegate(delegate: TabsScreenDelegate?) {
        tabsScreenDelegate = WeakReference(delegate)
    }

    override fun getAssociatedFragment(): Fragment? = tabsScreenDelegate.get()?.getFragmentForTabsScreen(this)

    private fun onMenuItemAttributesChange() {
        tabsScreenDelegate.get()?.onMenuItemAttributesChange(this)
    }

    private fun onIconChange() {
        isMenuItemIconInvalidated = true
        onMenuItemAttributesChange()
    }

    internal fun onViewManagerAddEventEmitters() {
        // When this is called from View Manager the view tag is already set
        check(id != NO_ID) { "[RNScreens] TabsScreen must have its tag set when registering event emitters" }
        eventEmitter = TabsScreenEventEmitter(reactContext, id)
    }

    /**
     * Notify the view that it's associated fragment got its config updated.
     *
     * There are cases where the fragment will receive configuration change, but it's view will not,
     * e.g. theme update from JS via Appearance.setColorScheme.
     */
    internal fun onFragmentConfigurationChange(
        fragment: TabsScreenFragment,
        config: Configuration,
    ) {
        tabsScreenDelegate.get()?.onFragmentConfigurationChange(this, config)
    }

    // region ScrollViewSeeking
    override fun registerScrollView(
        marker: ScrollViewMarker,
        scrollView: ViewGroup,
    ) {
        containerItemSupport.registerScrollView(scrollView)
    }

    // endregion

    // region ContainerItem

    override fun registerNestedContainer(container: Container) = containerItemSupport.registerNestedContainer(container)

    override fun unregisterNestedContainer(container: Container) = containerItemSupport.unregisterNestedContainer(container)

    override fun resolveNestedContainer(): Container? = containerItemSupport.resolveNestedContainer()

    override fun findContentScrollView(): ViewGroup? = containerItemSupport.findContentScrollView(this)

    // TabsScreen has no `preventNativeDismiss` flag of its own - it only forwards
    // the question to its nested container.
    override fun wantsToPreventStackNativeDismiss(): ContainerItem? = resolveNestedContainer()?.wantsToPreventStackNativeDismiss()

    // endregion

    companion object {
        const val TAG = "TabsScreen"
    }
}
