import{n as r}from"./chunk-Y2CYZVJY-CrVYBJys.js";import"./src-99-RUZzy.js";import"./chunk-DU6HZSFF-Dc99mE1n.js";import"./chunk-75Z2AOVW-B6tGnT-M.js";import"./chunk-PWAF6VOD-DQYnP0jP.js";import"./chunk-GMAD6QVW-DyIK6Py8.js";import"./chunk-P2QGCYS3-SDY_B7f6.js";import"./chunk-4HAMMTFA-DKZcDwuK.js";import"./chunk-GVQU2GXP-8Sa2ohse.js";import"./chunk-OSK3NFVY-D75usAvv.js";import"./chunk-F27PBJKO-VZK_jnBw.js";import"./chunk-XXDRQBXY-C7unKETI.js";import"./chunk-POPQ4Y6H-qf3N8tzR.js";import"./chunk-L3NEJ4N5-i_UN9Z8c.js";import{r as o,t as m}from"./chunk-SHT3W25Y-NPr5kKKj.js";import"./mermaid.core-BabNUY5H.js";var $=m({defaultLayout:"swimlane",styles:r(t=>`${o(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles")});export{$ as diagram};
