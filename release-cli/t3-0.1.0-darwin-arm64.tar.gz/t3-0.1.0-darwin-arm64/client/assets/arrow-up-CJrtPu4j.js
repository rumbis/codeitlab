import{a as r}from"./chevron-right-BMMC4U6n.js";var a=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],e=r("arrow-up",a);export{e as t};
