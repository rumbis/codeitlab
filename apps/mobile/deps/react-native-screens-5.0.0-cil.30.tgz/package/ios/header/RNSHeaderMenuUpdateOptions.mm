#import "RNSHeaderMenuUpdateOptions.h"
#import "RNSHeaderIconMapper.h"
#import "RNSHeaderMenuMapper.h"

#pragma mark - Helpers

static BOOL RNSDictHasKey(NSDictionary *dict, NSString *key)
{
  return [dict objectForKey:key] != nil;
}

static NSString *_Nullable RNSResolveStringFromDict(NSDictionary *dict, NSString *key, NSString *_Nullable fallback)
{
  id value = dict[key];
  if (value == nil) {
    return fallback;
  }
  if ([value isKindOfClass:[NSNull class]]) {
    return nil;
  }
  if ([value isKindOfClass:[NSString class]]) {
    return value;
  }
  return fallback;
}

static RNSHeaderIconData
    *_Nullable RNSResolveIconFromDict(NSDictionary *dict, NSString *key, RNSHeaderIconData *_Nullable fallback)
{
  id value = dict[key];
  if (value == nil) {
    return fallback;
  }
  if ([value isKindOfClass:[NSNull class]]) {
    return nil;
  }
  return [RNSHeaderIconMapper iconFromDictionary:value] ?: fallback;
}

#pragma mark - RNSMenuItemUpdateOptions

@implementation RNSMenuItemUpdateOptions

- (instancetype)initWithTitle:(nullable NSString *)title
                     hasTitle:(BOOL)hasTitle
                         icon:(nullable RNSHeaderIconData *)icon
                      hasIcon:(BOOL)hasIcon
               hasToggleState:(BOOL)hasToggleState
                  toggleState:(BOOL)toggleState
                     hasState:(BOOL)hasState
                        state:(UIMenuElementState)state
{
  if (self = [super init]) {
    _title = [title copy];
    _hasTitle = hasTitle;
    _icon = icon;
    _hasIcon = hasIcon;
    _hasToggleState = hasToggleState;
    _toggleState = toggleState;
    _hasState = hasState;
    _state = state;
  }
  return self;
}

+ (instancetype)fromDictionary:(NSDictionary *)dict
{
  BOOL hasTitle = RNSDictHasKey(dict, @"title");
  NSString *title = hasTitle ? RNSResolveStringFromDict(dict, @"title", nil) : nil;

  BOOL hasIcon = RNSDictHasKey(dict, @"icon");
  RNSHeaderIconData *icon = hasIcon ? RNSResolveIconFromDict(dict, @"icon", nil) : nil;

  BOOL hasToggleState = NO;
  BOOL toggleState = NO;
  id toggleValue = dict[@"toggleState"];
  if ([toggleValue isKindOfClass:[NSNumber class]]) {
    hasToggleState = YES;
    toggleState = [toggleValue boolValue];
  }

  BOOL hasState = RNSDictHasKey(dict, @"state");
  UIMenuElementState state =
      [RNSHeaderMenuMapper menuItemStateFromString:RNSResolveStringFromDict(dict, @"state", nil)];

  return [[RNSMenuItemUpdateOptions alloc] initWithTitle:title
                                                hasTitle:hasTitle
                                                    icon:icon
                                                 hasIcon:hasIcon
                                          hasToggleState:hasToggleState
                                             toggleState:toggleState
                                                hasState:hasState
                                                   state:state];
}

+ (RNSHeaderMenuItemData *)applyOptions:(RNSMenuItemUpdateOptions *)options toMenuItem:(RNSHeaderMenuItemData *)old
{
  NSString *title = options.hasTitle ? options.title : old.title;
  RNSHeaderIconData *icon = options.hasIcon ? options.icon : old.icon;

  return [[RNSHeaderMenuItemData alloc] initWithId:old.menuElementId
                                                  title:title
                                               subtitle:old.subtitle
                                               disabled:old.disabled
                                            destructive:old.destructive
                                               itemType:old.itemType
                                                  state:options.hasState ? options.state : old.state
                                     initialToggleState:old.initialToggleState
                                     keepsMenuPresented:old.keepsMenuPresented
                                                   icon:icon];
}

@end

#pragma mark - RNSMenuUpdateOptions

@implementation RNSMenuUpdateOptions

- (instancetype)initWithTitle:(nullable NSString *)title
                     hasTitle:(BOOL)hasTitle
                         icon:(nullable RNSHeaderIconData *)icon
                      hasIcon:(BOOL)hasIcon
{
  if (self = [super init]) {
    _title = [title copy];
    _hasTitle = hasTitle;
    _icon = icon;
    _hasIcon = hasIcon;
  }
  return self;
}

+ (instancetype)fromDictionary:(NSDictionary *)dict
{
  BOOL hasTitle = RNSDictHasKey(dict, @"title");
  NSString *title = hasTitle ? RNSResolveStringFromDict(dict, @"title", nil) : nil;

  BOOL hasIcon = RNSDictHasKey(dict, @"icon");
  RNSHeaderIconData *icon = hasIcon ? RNSResolveIconFromDict(dict, @"icon", nil) : nil;

  return [[RNSMenuUpdateOptions alloc] initWithTitle:title hasTitle:hasTitle icon:icon hasIcon:hasIcon];
}

+ (RNSHeaderMenuData *)applyOptions:(RNSMenuUpdateOptions *)options toMenu:(RNSHeaderMenuData *)old
{
  NSString *title = options.hasTitle ? options.title : old.title;
  RNSHeaderIconData *icon = options.hasIcon ? options.icon : old.icon;

  return [[RNSHeaderMenuData alloc] initWithId:old.menuElementId
                                         title:title
                               singleSelection:old.singleSelection
                                 displayInline:old.displayInline
                              displayAsPalette:old.displayAsPalette
                                      children:old.children
                                          icon:icon];
}

@end
