var e="CodeitLab";function a(r,o="Agent"){const t=(r??"").trim();return t.length===0?`${e} ${o}`:t.toLowerCase().startsWith("CodeitLab".toLowerCase())?t:`${e} ${t}`}export{a as t};
