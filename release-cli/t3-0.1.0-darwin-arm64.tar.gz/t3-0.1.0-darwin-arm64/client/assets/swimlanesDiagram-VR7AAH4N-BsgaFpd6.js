import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-oBChb5qS.js";import"./chunk-DU6HZSFF-DPfd14s7.js";import"./chunk-75Z2AOVW-BDbcAcDj.js";import"./chunk-PWAF6VOD-BfhPp4ST.js";import"./chunk-GMAD6QVW-CdlNuGwj.js";import"./chunk-P2QGCYS3-MaLvv0B9.js";import"./chunk-4HAMMTFA-2er1bnj8.js";import"./chunk-GVQU2GXP-BfKWBdxM.js";import"./chunk-OSK3NFVY-D8Cegd4N.js";import"./chunk-F27PBJKO-CR01wL9_.js";import"./chunk-XXDRQBXY-BvKO0v-W.js";import"./chunk-POPQ4Y6H-CicWtscd.js";import"./chunk-L3NEJ4N5-6u8Gz91Y.js";import{r as t,t as n}from"./chunk-SHT3W25Y-YXHFVAYo.js";import"./mermaid.core-MkIehl4t.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
//# sourceMappingURL=swimlanesDiagram-VR7AAH4N-BsgaFpd6.js.map