import"./chunk-FOHPRMQF-HhYVbNwW.js";import{O as t}from"./mermaid-parser.core-C-dfRkIv.js";export{t as createEventModelingServices};
