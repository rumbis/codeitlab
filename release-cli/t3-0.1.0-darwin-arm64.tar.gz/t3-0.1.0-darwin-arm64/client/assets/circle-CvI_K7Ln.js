import{a as c}from"./chevron-right-BMMC4U6n.js";var r=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],a=c("circle",r);export{a as t};
