import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";var t=e(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,`getIconStyles`);export{t};
//# sourceMappingURL=chunk-5VM5RSS4-ZNzvKenW.js.map