#import "RNSHeaderConfigComponentView.h"
#import "RNSConversions-Stack.h"
#import "RNSConversions.h"
#import "RNSHeaderAppearanceMapper.h"
#import "RNSHeaderConfigEventEmitter.h"
#import "RNSHeaderConfigShadowStateProxy.h"
#import "RNSHeaderItemComponentView.h"
#import "RNSHeaderItemSpacerComponentView.h"
#import "RNSHeaderMenuCoordinator.h"
#import "RNSHeaderMenuFinder.h"
#import "RNSHeaderMenuMapper.h"
#import "RNSHeaderMenuUpdateOptions.h"
#import "RNSImageLoadingHelper.h"
#import "RNSSearchBar.h"
#import "RNSStackNavigationController.h"
#import "RNSStackScreenProviding.h"

#import <React/RCTConversions.h>
#import <React/RCTConvert.h>
#import <React/RCTImageLoader.h>
#import <React/RCTLog.h>
#import <react/renderer/components/rnscreens/Props.h>
#import <react/renderer/components/rnscreens/RCTComponentViewHelpers.h>
#import <react/renderer/components/rnscreens/RNSHeaderConfigComponentDescriptor.h>
#import <react/utils/ManagedObjectWrapper.h>

namespace react = facebook::react;

static void RNSAssertIsValidHeaderChild(UIView *child)
{
  RCTAssert(
      [child isKindOfClass:RNSHeaderItemComponentView.class] ||
          [child isKindOfClass:RNSHeaderItemSpacerComponentView.class] || [child isKindOfClass:RNSSearchBar.class],
      @"[RNScreens] Unexpected child of type: %@, expected %@, %@ or %@",
      child.class,
      RNSHeaderItemComponentView.class,
      RNSHeaderItemSpacerComponentView.class,
      RNSSearchBar.class);
}

@interface RNSHeaderConfigComponentView () <RCTRNSHeaderConfigIOSViewProtocol, RNSSearchBarNavigationItemDelegate>
@end

@implementation RNSHeaderConfigComponentView {
  std::shared_ptr<const react::RNSHeaderConfigShadowNode::ConcreteState> _state;
  RNSHeaderConfigShadowStateProxy *_Nonnull _shadowStateProxy;
  RNSHeaderConfigEventEmitter *_Nonnull _reactEventEmitter;
  NSMutableArray<id> *_children;
  RCTImageLoader *_imageLoader;
  BOOL _hasAttachedToWindow;
}

- (instancetype)initWithFrame:(CGRect)frame
{
  if (self = [super initWithFrame:frame]) {
    static const auto defaultProps = std::make_shared<const react::RNSHeaderConfigIOSProps>();
    _props = defaultProps;
    _children = [NSMutableArray new];
    _shadowStateProxy = [[RNSHeaderConfigShadowStateProxy alloc] initWithHeaderConfigView:self];
    _reactEventEmitter = [RNSHeaderConfigEventEmitter new];
    [self resetProps];
  }
  return self;
}

- (void)resetProps
{
  _title = nil;
  _subtitle = nil;
  _hidden = NO;
  _tintColor = nil;
  _backButtonHidden = NO;
#if RNS_IPHONE_OS_VERSION_AVAILABLE(16_0) && !TARGET_OS_TV
  if (@available(iOS 16.0, *)) {
    _navigationItemStyle = UINavigationItemStyleNavigator;
  }
#endif
  _largeTitle = nil;
  _largeSubtitle = nil;
  _largeTitleEnabled = NO;
  _prompt = nil;
#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0)
  if (@available(iOS 27.0, *)) {
    _minimizationBehavior = UIBarMinimizationBehaviorAutomatic;
    _restorationBehavior = UIBarMinimizationRestorationBehaviorAutomatic;
  }
#endif // Check for iOS >= 27
  _backButtonTitle = nil;
  _backButtonDisplayMode = UINavigationItemBackButtonDisplayModeDefault;
  _backButtonMenuEnabled = YES;
  _titleMenu = nil;
  _standardAppearance = nil;
  _scrollEdgeAppearance = nil;
}

- (nullable RNSSearchBar *)searchBar
{
  for (UIView *child in _children) {
    if ([child isKindOfClass:RNSSearchBar.class]) {
      return (RNSSearchBar *)child;
    }
  }
  return nil;
}

- (NSArray<id> *)children
{
  return [_children copy];
}

#pragma mark - RNSImageLoading

- (void)loadImageFromJsonSource:(NSDictionary *)jsonSource
                     asTemplate:(BOOL)isTemplate
         withCompletionCallback:(void (^)(UIImage *_Nullable image))completionBlock
{
  if (_imageLoader == nil) {
    RCTLogError(@"[RNScreens] imageLoader must not be nil when loading images");
    completionBlock(nil);
    return;
  }

  RCTImageSource *imageSource = [RCTConvert RCTImageSource:jsonSource];
  if (imageSource == nil) {
    RCTLogError(@"[RNScreens] Expected nonnil image source");
    completionBlock(nil);
    return;
  }

  [RNSImageLoadingHelper loadImageFromSource:imageSource
                             withImageLoader:_imageLoader
                                  asTemplate:isTemplate
                             completionBlock:completionBlock];
}

#pragma mark - UIView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
  for (UIView *child in [_children reverseObjectEnumerator]) {
    if ([child isKindOfClass:RNSHeaderItemComponentView.class] && child.window != nil) {
      for (UIView *hitableView in [child.subviews reverseObjectEnumerator]) {
        CGPoint convertedPoint = [self convertPoint:point toView:hitableView];
        UIView *hitTestResult = [hitableView hitTest:convertedPoint withEvent:event];

        if (hitTestResult != nil) {
          return hitTestResult;
        }
      }
    }
  }
  return nil;
}

- (void)didMoveToWindow
{
  if (self.window != nil) {
    [[self requireNavigationController] setNavigationBarFrameChangeDelegate:self];
    if (_hasAttachedToWindow) {
      // UIKit is already transitioning the retained screen's bar items. Replacing
      // them on reattachment starts a second layout inside the moving glass.
      [self.headerCoordinator applyConfigProperties];
    } else {
      [self.headerCoordinator rebuild];
      _hasAttachedToWindow = YES;
    }
  }
  [super didMoveToWindow];
}

#pragma mark - Child mounting

- (void)mountChildComponentView:(UIView<RCTComponentViewProtocol> *)childComponentView index:(NSInteger)index
{
  RNSAssertIsValidHeaderChild(childComponentView);

  // Do NOT call super — children are not added to the view hierarchy.
  // They are tracked here and read by the coordinator during rebuild.
  [_children insertObject:childComponentView atIndex:index];

  if ([childComponentView isKindOfClass:RNSHeaderItemComponentView.class]) {
    ((RNSHeaderItemComponentView *)childComponentView).invalidationDelegate = self;
  } else if ([childComponentView isKindOfClass:RNSHeaderItemSpacerComponentView.class]) {
    ((RNSHeaderItemSpacerComponentView *)childComponentView).invalidationDelegate = self;
  } else if ([childComponentView isKindOfClass:RNSSearchBar.class]) {
    ((RNSSearchBar *)childComponentView).navigationItemDelegate = self;
  }

  [self.headerCoordinator rebuild];
}

- (void)unmountChildComponentView:(UIView<RCTComponentViewProtocol> *)childComponentView index:(NSInteger)index
{
  RNSAssertIsValidHeaderChild(childComponentView);

  if ([childComponentView isKindOfClass:RNSHeaderItemComponentView.class]) {
    ((RNSHeaderItemComponentView *)childComponentView).invalidationDelegate = nil;
  } else if ([childComponentView isKindOfClass:RNSHeaderItemSpacerComponentView.class]) {
    ((RNSHeaderItemSpacerComponentView *)childComponentView).invalidationDelegate = nil;
  } else if ([childComponentView isKindOfClass:RNSSearchBar.class]) {
    ((RNSSearchBar *)childComponentView).navigationItemDelegate = nil;
  }

  [_children removeObjectAtIndex:index];
  [self.headerCoordinator rebuild];
}

#pragma mark - RNSSearchBarNavigationItemDelegate

- (void)searchBarDidUpdateNavigationItem:(RNSSearchBar *)searchBar
{
  [self.headerCoordinator applyConfigProperties];
}

#pragma mark - RNSHeaderItemInvalidationDelegate

- (void)headerItemDidInvalidateWithId:(NSString *)itemId
{
  if (itemId == nil) {
    RCTLogWarn(@"[RNScreens] headerItemDidInvalidateWithId called with nil id, will run full header rebuild");
    [self.headerCoordinator rebuild];
    return;
  }
  [self.headerCoordinator rebuildItemWithId:itemId];
}

- (void)headerItemMenuDidChangeWithId:(NSString *)itemId
{
  if (itemId == nil) {
    RCTLogWarn(@"[RNScreens] headerItemMenuDidChangeWithId called with nil id, will run full header rebuild");
    [self.headerCoordinator rebuild];
    return;
  }
  [self.headerCoordinator resetTrackerForItemWithId:itemId];
  [self.headerCoordinator reapplyMenuForItemWithId:itemId];
}

/**
 * Same as headerItemDidInvalidateWithId, but handles view commands and doesn't reset the tracker
 */
- (void)headerItemMenuDidUpdateFromCommandWithId:(NSString *)itemId
{
  if (itemId == nil) {
    RCTLogWarn(
        @"[RNScreens] headerItemMenuDidUpdateFromCommandWithId called with nil id, will run full header rebuild");
    [self.headerCoordinator rebuild];
    return;
  }
  [self.headerCoordinator reapplyMenuForItemWithId:itemId];
}

- (void)headerItemSpacerDidInvalidate
{
  [self.headerCoordinator rebuild];
}

#pragma mark - RNSHeaderEventsDelegate

- (void)didPressMenuItem:(NSString *)menuItemId
{
  [_reactEventEmitter emitOnMenuItemPress:menuItemId];
}

- (void)didChangeSelectionForMenu:(NSString *)menuId selectedMenuItemIds:(NSArray<NSString *> *)selectedIds
{
  [_reactEventEmitter emitOnMenuSelectionChange:menuId selectedMenuItemIds:selectedIds];
}

- (void)didPressHeaderItem:(NSString *)itemId
{
  for (UIView *child in _children) {
    if ([child isKindOfClass:RNSHeaderItemComponentView.class]) {
      RNSHeaderItemComponentView *item = (RNSHeaderItemComponentView *)child;
      if ([item.itemId isEqualToString:itemId]) {
        [item emitOnPress];
        return;
      }
    }
  }
}

#pragma mark - RNSViewFrameChangeDelegate

- (void)viewFrameDidChange:(nonnull UINavigationBar *)navigationBar
{
  if (_state == nullptr || self.superview == nil) {
    return;
  }

  for (UIView *child in _children) {
    if ([child isKindOfClass:RNSHeaderItemComponentView.class]) {
      [(id<RNSViewFrameChangeDelegate>)(child) viewFrameDidChange:navigationBar];
    }
  }

  UIView *screenView = self.superview;
  CGRect navBarFrame = [navigationBar convertRect:navigationBar.bounds toView:screenView];
  [_shadowStateProxy updateShadowStateWithFrame:navBarFrame];
}

#pragma mark - Commands

- (void)handleCommand:(const NSString *)commandName args:(const NSArray *)args
{
  RCTRNSHeaderConfigIOSHandleCommand(self, commandName, args);
}

- (void)setMenuItemOptions:(NSString *)menuItemId options:(const NSArray *)options
{
  NSDictionary *dict = [self extractOptionsDict:options];
  if (menuItemId == nil || dict == nil) {
    return;
  }

  RNSMenuElementLocator *locator = [RNSHeaderMenuFinder findMenuElementWithId:menuItemId
                                                                inHeaderItems:[self headerItems]
                                                                    titleMenu:_titleMenu];
  if (locator == nil) {
    RCTLogWarn(@"[RNScreens] setMenuItemOptions: element with id \"%@\" not found", menuItemId);
    return;
  }
  if (![locator.searchResult.element isKindOfClass:[RNSHeaderMenuItemData class]]) {
    RCTLogWarn(@"[RNScreens] setMenuItemOptions: element \"%@\" is a menu, expected menuItem", menuItemId);
    return;
  }

  RNSMenuItemUpdateOptions *updateOptions = [RNSMenuItemUpdateOptions fromDictionary:dict];
  RNSHeaderMenuItemData *oldItemData = (RNSHeaderMenuItemData *)locator.searchResult.element;
  RNSHeaderMenuItemData *newItemData = [RNSMenuItemUpdateOptions applyOptions:updateOptions toMenuItem:oldItemData];

  if (updateOptions.hasToggleState && locator.rootMenu != nil && locator.trackerItemId != nil) {
    BOOL isToggle = oldItemData.itemType == RNSMenuItemTypeToggle ||
        (oldItemData.itemType == RNSMenuItemTypeAutomatic &&
         [RNSHeaderMenuFinder singleSelectionRootForElementWithId:menuItemId inMenu:locator.rootMenu] != nil);
    if (isToggle) {
      [self.headerCoordinator setToggleState:updateOptions.toggleState
                            forMenuElementId:menuItemId
                               trackerItemId:locator.trackerItemId
                                    rootMenu:locator.rootMenu
                                  parentMenu:locator.searchResult.parentMenu];
    }
  }

  switch (locator.position) {
    case RNSMenuElementPositionItem:
      RCTAssert(
          [locator.headerItem isKindOfClass:RNSHeaderItemComponentView.class],
          @"[RNScreens] headerItem is expected to be of type RNSHeaderItemComponentView");
      [static_cast<RNSHeaderItemComponentView *>(locator.headerItem)
          updateMenuElementWithId:menuItemId
                      withElement:newItemData
                       parentMenu:locator.searchResult.parentMenu
             inMenuRepresentation:locator.inMenuRepresentation];
      break;
    case RNSMenuElementPositionTitle:
      if (locator.searchResult.parentMenu != nil) {
        _titleMenu = [RNSHeaderMenuCoordinator menu:_titleMenu replacingChildWithId:menuItemId withElement:newItemData];
      }
      [self.headerCoordinator reapplyTitleMenu];
      break;
    case RNSMenuElementPositionOverflow:
      // TODO: handle overflow menu
      break;
  }
}

- (void)setMenuOptions:(NSString *)menuElementId options:(const NSArray *)options
{
  NSDictionary *dict = [self extractOptionsDict:options];
  if (menuElementId == nil || dict == nil) {
    return;
  }

  RNSMenuElementLocator *locator = [RNSHeaderMenuFinder findMenuElementWithId:menuElementId
                                                                inHeaderItems:[self headerItems]
                                                                    titleMenu:_titleMenu];
  if (locator == nil) {
    RCTLogWarn(@"[RNScreens] setMenuOptions: element with id \"%@\" not found", menuElementId);
    return;
  }
  if (![locator.searchResult.element isKindOfClass:[RNSHeaderMenuData class]]) {
    RCTLogWarn(@"[RNScreens] setMenuOptions: element \"%@\" is a menuItem, expected menu", menuElementId);
    return;
  }

  RNSMenuUpdateOptions *updateOptions = [RNSMenuUpdateOptions fromDictionary:dict];
  RNSHeaderMenuData *oldMenuItem = (RNSHeaderMenuData *)locator.searchResult.element;
  RNSHeaderMenuData *newMenuItem = [RNSMenuUpdateOptions applyOptions:updateOptions toMenu:oldMenuItem];

  switch (locator.position) {
    case RNSMenuElementPositionItem:
      RCTAssert(
          [locator.headerItem isKindOfClass:RNSHeaderItemComponentView.class],
          @"[RNScreens] headerItem is expected to be of type RNSHeaderItemComponentView");
      [static_cast<RNSHeaderItemComponentView *>(locator.headerItem)
          updateMenuElementWithId:menuElementId
                      withElement:newMenuItem
                       parentMenu:locator.searchResult.parentMenu
             inMenuRepresentation:locator.inMenuRepresentation];
      break;
    case RNSMenuElementPositionTitle:
      if (locator.searchResult.parentMenu == nil) {
        _titleMenu = (RNSHeaderMenuData *)newMenuItem;
      } else {
        _titleMenu = [RNSHeaderMenuCoordinator menu:_titleMenu
                               replacingChildWithId:menuElementId
                                        withElement:newMenuItem];
      }
      [self.headerCoordinator reapplyTitleMenu];
      break;
    case RNSMenuElementPositionOverflow:
      // TODO: handle overflow menu
      break;
  }
}

- (nullable NSDictionary *)extractOptionsDict:(const NSArray *)options
{
  if (options.count == 0) {
    return nil;
  }
  id first = options[0];
  if (![first isKindOfClass:[NSDictionary class]]) {
    return nil;
  }
  NSDictionary *dict = (NSDictionary *)first;
  return dict.count > 0 ? dict : nil;
}

- (NSArray<RNSHeaderItemComponentView *> *)headerItems
{
  NSMutableArray<RNSHeaderItemComponentView *> *items = [NSMutableArray new];
  for (UIView *child in _children) {
    if ([child isKindOfClass:RNSHeaderItemComponentView.class]) {
      [items addObject:(RNSHeaderItemComponentView *)child];
    }
  }
  return items;
}

#pragma mark - RCTComponentViewProtocol

- (void)updateState:(const react::State::Shared &)state oldState:(const react::State::Shared &)oldState
{
  _state = std::static_pointer_cast<const react::RNSHeaderConfigShadowNode::ConcreteState>(state);
  if (auto imgLoaderPtr = _state.get()->getData().getImageLoader().lock()) {
    _imageLoader = react::unwrapManagedObject(imgLoaderPtr);
  }
}

- (react::RNSHeaderConfigShadowNode::ConcreteState::Shared)state
{
  return _state;
}

- (void)updateProps:(const react::Props::Shared &)props oldProps:(const react::Props::Shared &)oldProps
{
  const auto &newHeaderProps = *std::static_pointer_cast<const react::RNSHeaderConfigIOSProps>(props);
  const auto &oldHeaderProps = *std::static_pointer_cast<const react::RNSHeaderConfigIOSProps>(_props);

  BOOL titleMenuDidChange = NO;

  if (oldHeaderProps.tintColor != newHeaderProps.tintColor) {
    _tintColor = RCTUIColorFromSharedColor(newHeaderProps.tintColor);
  }

  if (oldHeaderProps.title != newHeaderProps.title) {
    _title = RCTNSStringFromStringNilIfEmpty(newHeaderProps.title);
  }

  if (oldHeaderProps.subtitle != newHeaderProps.subtitle) {
    _subtitle = RCTNSStringFromStringNilIfEmpty(newHeaderProps.subtitle);
  }

  if (oldHeaderProps.hidden != newHeaderProps.hidden) {
    _hidden = newHeaderProps.hidden;
  }

  if (oldHeaderProps.backButtonHidden != newHeaderProps.backButtonHidden) {
    _backButtonHidden = newHeaderProps.backButtonHidden;
  }
#if RNS_IPHONE_OS_VERSION_AVAILABLE(16_0) && !TARGET_OS_TV
  if (@available(iOS 16.0, *)) {
    if (oldHeaderProps.navigationItemStyle != newHeaderProps.navigationItemStyle) {
      _navigationItemStyle = rnscreens::conversion::UINavigationItemStyleFromReactRNSHeaderConfigIOSNavigationItemStyle(
          newHeaderProps.navigationItemStyle);
    }
  }
#endif

  if (oldHeaderProps.largeTitle != newHeaderProps.largeTitle) {
    _largeTitle = RCTNSStringFromStringNilIfEmpty(newHeaderProps.largeTitle);
  }

  if (oldHeaderProps.largeSubtitle != newHeaderProps.largeSubtitle) {
    _largeSubtitle = RCTNSStringFromStringNilIfEmpty(newHeaderProps.largeSubtitle);
  }

  if (oldHeaderProps.largeTitleEnabled != newHeaderProps.largeTitleEnabled) {
    _largeTitleEnabled = newHeaderProps.largeTitleEnabled;
  }

  if (oldHeaderProps.prompt != newHeaderProps.prompt) {
    _prompt = RCTNSStringFromStringNilIfEmpty(newHeaderProps.prompt);
  }

  if (oldHeaderProps.minimizationBehavior != newHeaderProps.minimizationBehavior) {
#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0)
    if (@available(iOS 27.0, *)) {
      _minimizationBehavior =
          rnscreens::conversion::UIBarMinimizationBehaviorFromReactRNSHeaderConfigIOSMinimizationBehavior(
              newHeaderProps.minimizationBehavior);
    } else
#endif // Check for iOS >= 27
      if (newHeaderProps.minimizationBehavior != react::RNSHeaderConfigIOSMinimizationBehavior::Automatic) {
        RCTLogWarn(@"[RNScreens] minimizationBehavior is supported for iOS >= 27");
      }
  }

  if (oldHeaderProps.restorationBehavior != newHeaderProps.restorationBehavior) {
#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0)
    if (@available(iOS 27.0, *)) {
      _restorationBehavior =
          rnscreens::conversion::UIBarMinimizationRestorationBehaviorFromReactRNSHeaderConfigIOSRestorationBehavior(
              newHeaderProps.restorationBehavior);
    } else
#endif // Check for iOS >= 27
      if (newHeaderProps.restorationBehavior != react::RNSHeaderConfigIOSRestorationBehavior::Automatic) {
        RCTLogWarn(@"[RNScreens] restorationBehavior is supported for iOS >= 27");
      }
  }

  if (oldHeaderProps.backButtonTitle != newHeaderProps.backButtonTitle) {
    _backButtonTitle = RCTNSStringFromStringNilIfEmpty(newHeaderProps.backButtonTitle);
  }

  if (oldHeaderProps.backButtonDisplayMode != newHeaderProps.backButtonDisplayMode) {
    _backButtonDisplayMode =
        rnscreens::conversion::convert<UINavigationItemBackButtonDisplayMode>(newHeaderProps.backButtonDisplayMode);
  }

  if (oldHeaderProps.backButtonMenuEnabled != newHeaderProps.backButtonMenuEnabled) {
    _backButtonMenuEnabled = newHeaderProps.backButtonMenuEnabled;
  }

  if (oldHeaderProps.standardAppearance != newHeaderProps.standardAppearance) {
    _standardAppearance = [RNSHeaderAppearanceMapper
        appearanceFromDictionary:[self dictionaryFromAppearanceProp:newHeaderProps.standardAppearance]];
  }

  if (oldHeaderProps.scrollEdgeAppearance != newHeaderProps.scrollEdgeAppearance) {
    _scrollEdgeAppearance = [RNSHeaderAppearanceMapper
        scrollEdgeAppearanceFromDictionary:[self dictionaryFromAppearanceProp:newHeaderProps.scrollEdgeAppearance]];
  }

  if (oldHeaderProps.titleMenu != newHeaderProps.titleMenu) {
    _titleMenu = [RNSHeaderMenuMapper
        menuFromDictionary:rnscreens::conversion::RNSConvertFollyDynamicToId(newHeaderProps.titleMenu)];
    titleMenuDidChange = YES;
  }

  [super updateProps:props oldProps:oldProps];

  [self.headerCoordinator applyConfigProperties];

  if (titleMenuDidChange) {
    // title menu is a prop on the navigation item, not on one of the bar button items
    // thus it is not configured with matching RNSHeaderItemComponentView
    // but here directly
    [self.headerCoordinator resetTitleMenuTracker];
    [self.headerCoordinator reapplyTitleMenu];
  }
}

+ (react::ComponentDescriptorProvider)componentDescriptorProvider
{
  return react::concreteComponentDescriptorProvider<react::RNSHeaderConfigComponentDescriptor>();
}

+ (BOOL)shouldBeRecycled
{
  return NO;
}

- (void)updateEventEmitter:(const facebook::react::EventEmitter::Shared &)eventEmitter
{
  [super updateEventEmitter:eventEmitter];
  [_reactEventEmitter
      updateEventEmitter:std::static_pointer_cast<const react::RNSHeaderConfigIOSEventEmitter>(eventEmitter)];
}

#pragma mark - Private

- (nullable NSDictionary *)dictionaryFromAppearanceProp:(const folly::dynamic &)appearanceProp
{
  if (appearanceProp.type() != folly::dynamic::OBJECT) {
    return nil;
  }

  return rnscreens::conversion::RNSConvertFollyDynamicToId(appearanceProp);
}

- (id<RNSStackScreenProviding>)requireScreen
{
  RCTAssert(
      [self.superview conformsToProtocol:@protocol(RNSStackScreenProviding)],
      @"[RNScreens] Header Config should be a direct child of a stack screen, got %@",
      self.superview);
  return (id<RNSStackScreenProviding>)self.superview;
}

- (nullable RNSHeaderCoordinator *)headerCoordinator
{
  if (self.superview == nil) {
    return nil;
  }
  return [[self requireScreen] headerCoordinator];
}

- (RNSStackNavigationController *)requireNavigationController
{
  UINavigationController *navController = [[self requireScreen] controller].navigationController;
  RCTAssert(navController != nil, @"[RNScreens] NavigationController should be initialized at this point");
  RCTAssert(
      [navController isKindOfClass:RNSStackNavigationController.class],
      @"[RNScreens] NavigationController should be instance of RNSStackNavigationController");
  return (RNSStackNavigationController *)navController;
}

#pragma mark - Dynamic frameworks support

// Needed because of this: https://github.com/facebook/react-native/pull/37274
#ifdef RCT_DYNAMIC_FRAMEWORKS
+ (void)load
{
  [super load];
}
#endif // RCT_DYNAMIC_FRAMEWORKS

@end

Class<RCTComponentViewProtocol> RNSHeaderConfigComponentViewCls(void)
{
  return RNSHeaderConfigComponentView.class;
}
