import{a}from"./chevron-right-BMMC4U6n.js";var e=[["path",{d:"m12 14 4-4",key:"9kzdfg"}],["path",{d:"M3.34 19a10 10 0 1 1 17.32 0",key:"19p75a"}]],r=a("gauge",e);export{r as t};
