import{a}from"./chevron-right-BMMC4U6n.js";var e=[["path",{d:"M12 19h8",key:"baeox8"}],["path",{d:"m4 17 6-6-6-6",key:"1yngyt"}]],t=a("terminal",e);export{t};
