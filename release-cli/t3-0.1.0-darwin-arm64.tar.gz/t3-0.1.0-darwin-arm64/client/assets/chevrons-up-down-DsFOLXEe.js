import{a as o}from"./chevron-right-BMMC4U6n.js";var e=[["path",{d:"m7 15 5 5 5-5",key:"1hf1tw"}],["path",{d:"m7 9 5-5 5 5",key:"sgt6xg"}]],r=o("chevrons-up-down",e);export{r as t};
