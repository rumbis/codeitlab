import{a as r}from"./chevron-right-BMMC4U6n.js";var a=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],t=r("arrow-right",a);export{t};
