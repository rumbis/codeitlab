import{n as e}from"./SettingsPanels-B-JPZ5yq.js";var t=e;export{t as component};
//# sourceMappingURL=settings.archived-CMATrqy2.js.map