import{i as e}from"./rolldown-runtime-kjsH4l9N.js";import{t as r}from"./react-DnSgFzL9.js";var t=e(r()),o=t.createContext({disabled:!1});function m(){return t.useContext(o)}export{m as t};
