import"./chunk-FOHPRMQF-HhYVbNwW.js";import{o}from"./mermaid-parser.core-C-dfRkIv.js";export{o as createTreemapServices};
