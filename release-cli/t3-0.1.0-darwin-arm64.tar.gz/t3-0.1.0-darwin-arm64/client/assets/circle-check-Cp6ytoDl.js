import{a as c}from"./chevron-right-BMMC4U6n.js";var e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],a=c("circle-check",e);export{a as t};
