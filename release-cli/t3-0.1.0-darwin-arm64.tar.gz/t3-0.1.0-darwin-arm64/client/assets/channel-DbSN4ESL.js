import{at as e,it as t}from"./chunk-DU6HZSFF-DPfd14s7.js";var n=(n,r)=>e.lang.round(t.parse(n)[r]);export{n as t};
//# sourceMappingURL=channel-DbSN4ESL.js.map