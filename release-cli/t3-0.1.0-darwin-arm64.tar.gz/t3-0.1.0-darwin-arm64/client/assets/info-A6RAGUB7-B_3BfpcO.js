import"./chunk-FOHPRMQF-HhYVbNwW.js";import{w as t}from"./mermaid-parser.core-C-dfRkIv.js";export{t as createInfoServices};
