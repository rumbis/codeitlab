import{a as e}from"./chevron-right-BUdSwOVV.js";var t=e(`square`,[[`rect`,{width:`18`,height:`18`,x:`3`,y:`3`,rx:`2`,key:`afitv7`}]]);export{t};
//# sourceMappingURL=square-BCOQmTJI.js.map