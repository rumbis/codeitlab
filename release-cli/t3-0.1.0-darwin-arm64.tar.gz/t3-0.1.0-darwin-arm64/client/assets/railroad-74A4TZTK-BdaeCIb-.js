import"./chunk-FOHPRMQF-HhYVbNwW.js";import{g as o}from"./mermaid-parser.core-C-dfRkIv.js";export{o as createRailroadServices};
