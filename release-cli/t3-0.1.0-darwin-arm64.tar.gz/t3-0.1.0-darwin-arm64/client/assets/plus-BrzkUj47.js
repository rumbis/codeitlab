import{a as e}from"./chevron-right-BUdSwOVV.js";var t=e(`plus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}],[`path`,{d:`M12 5v14`,key:`s699le`}]]);export{t};
//# sourceMappingURL=plus-BrzkUj47.js.map