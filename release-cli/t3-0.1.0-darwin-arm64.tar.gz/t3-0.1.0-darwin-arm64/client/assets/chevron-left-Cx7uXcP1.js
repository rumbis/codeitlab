import{a as e}from"./chevron-right-BUdSwOVV.js";var t=e(`chevron-left`,[[`path`,{d:`m15 18-6-6 6-6`,key:`1wnfg3`}]]);export{t};
//# sourceMappingURL=chevron-left-Cx7uXcP1.js.map