import{n as o}from"./SettingsPanels-Csr7UnOY.js";var n=o;export{n as component};
