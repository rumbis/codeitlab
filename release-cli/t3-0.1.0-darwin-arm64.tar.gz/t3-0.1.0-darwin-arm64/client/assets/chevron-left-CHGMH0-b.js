import{a as e}from"./chevron-right-BMMC4U6n.js";var o=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],a=e("chevron-left",o);export{a as t};
