var n=()=>null;export{n as component};
