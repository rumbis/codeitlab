import{a}from"./chevron-right-BMMC4U6n.js";var e=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],r=a("x",e);export{r as t};
