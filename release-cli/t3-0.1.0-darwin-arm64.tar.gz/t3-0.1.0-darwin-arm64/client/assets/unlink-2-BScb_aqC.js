import{a}from"./chevron-right-BMMC4U6n.js";var e=[["path",{d:"M15 7h2a5 5 0 0 1 0 10h-2m-6 0H7A5 5 0 0 1 7 7h2",key:"1re2ne"}]],r=a("unlink-2",e);export{r as t};
